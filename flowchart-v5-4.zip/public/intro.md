# What is it

This is a fully customizable interactive flowchart template for the web. You can explore and share different paths to see how decisions or processes unfold, whether you're mapping workflows, user journeys or complex logic.


# How to Use

Use the button below to start (and pause) the audio narration of the chart. You can also explore the chart yourself by selecting any visible items and moving along step by step.


# [Create your own](https://github.com/uclab-potsdam/interactive-flowchart)


